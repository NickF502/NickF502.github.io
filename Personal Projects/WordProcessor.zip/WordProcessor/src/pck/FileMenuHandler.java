package pck;


import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


/** Class that handles the events of the File Menu */
public class FileMenuHandler implements ActionListener {
	static JFrame jframe;
    protected static TextArea textBox;
    protected WordProcessorGUI gui;

	
	public FileMenuHandler (JFrame jf) {
		jframe = jf;
	    textBox = ((WordProcessorGUI) jframe).editingBox;
	    gui = (WordProcessorGUI) jframe;

	}
	
	
	/** Method to determine which File event was selected */
	public void actionPerformed(ActionEvent event) {
		String menuName = event.getActionCommand();

		if(menuName.equals("Open")) openFile();
		else if(menuName.equals("Save")) saveFile(false);
		else if(menuName.equals("Close")) closeFile();
		else if(menuName.equals("Force Close")) forceCloseFile();
		
	}
	
	/**
	 * A Method for loading a text document into the word processor
	 */
	private void openFile() {
		
		/* Before opening a file, check if the current file wishes to be saved*/
		int result = JOptionPane.showConfirmDialog(jframe, "Do you want to save before opening a new file?", "Opening", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
		
		/* If they wish to save, save and exit*/
		if(result == JOptionPane.YES_OPTION) saveFile(false);
		else if(result == JOptionPane.CANCEL_OPTION) return;

		/* Reset the textbox */
		textBox.setText("");
		
		/* Select a file to open using a JFileChooser*/
		JFileChooser chooser = new JFileChooser();
		chooser.showOpenDialog(null);
		
		String filePath = null;
		String fileName = null;

		try {
			filePath = chooser.getSelectedFile().getAbsolutePath();
			fileName = chooser.getSelectedFile().getName();			
		}
		catch(NullPointerException n){
			throw new NullFileSelectionException();
		}
		
		
		/* If the file's name does not end in .txt, throw an IllegalFileExtensionException */
		if(!filePath.substring(filePath.length()-4).equals(".txt")) {
			throw new IllegalFileExtentionException();
		}

		/* Set the name of the GUI window to the name of the file */
		gui.setTitle(fileName);
		
		/* Read in the text from the file line by line using a scanner and append it to the text area in the GUI */
		Scanner myInput = null; 
	    String inputLine;
	    
	    try {
	       myInput = new Scanner(new File(filePath));
	    } 
	    catch (FileNotFoundException e) {
	        e.printStackTrace();
	    }
	    
	    while (myInput.hasNextLine()) {
	         inputLine = myInput.nextLine();
	         textBox.append(inputLine + "\n");
	    }
	    
	    /* Close the scanner */
	    myInput.close();
	    
	    
	}

		

	
	
	/**
	 * A Method for quitting the word processor, which includes a prompt to saec before exiting
	 */
	static void closeFile() {
		
		/* Prompt the user to ask if they wish to save their work*/
		int result = JOptionPane.showConfirmDialog(jframe, "Do you want to save before exiting?", "Exiting", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        
		/* If they wish to save, save and exit*/
		if(result == JOptionPane.YES_OPTION){saveFile(true); System.exit(0);}
		
		/* If they do not wish to save, double prompt for confirmation */
        else if(result == JOptionPane.NO_OPTION) {
    		int result2 = JOptionPane.showConfirmDialog(jframe, "Are you sure you want to quit without saving?", "Exiting...", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(result2 == JOptionPane.YES_OPTION){System.exit(0);}
        }
		
	}
	
	static void saveFile(boolean closeWhenDone) {
		
		//chose file to save to
		JFileChooser chooser = new JFileChooser();
		chooser.showOpenDialog(null);
		String filePath = null;
		
		try {
			filePath = chooser.getSelectedFile().getAbsolutePath();			
		}
		catch(NullPointerException n) {
			chooser.setEnabled(false);
		}
		
		if(filePath != null) {
			
			try {
				
				/* Create a FileWriter to write to the desired file */
				FileWriter toNewFile = new FileWriter(filePath);			

				/* Read the lines from the textbox and write them to the desired file to save */
				String textboxText = textBox.getText();
				toNewFile.write(textboxText);
				
				/* Close the FileWriter and inform the user of success */
			    toNewFile.close();
			    JOptionPane.showMessageDialog(null, "Saved Successfully!");
			    
			    /* If file is being saved before closing, close the program*/
			    if(closeWhenDone) System.exit(0);
				
			}
			catch (FileNotFoundException fnfe) {
				File newFile = new File(filePath);
			}
			catch (IOException e) {
				JOptionPane.showMessageDialog(null, "An error occurred");
				e.printStackTrace();
			}
		}
		
		
	}
	
	
	private void forceCloseFile() {
		System.exit(0);
	}
	
}