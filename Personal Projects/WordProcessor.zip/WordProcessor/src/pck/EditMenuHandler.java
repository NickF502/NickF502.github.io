package pck;


import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


/** Class that handles the events of the File Menu */
public class EditMenuHandler implements ActionListener {
	JFrame jframe;
    protected TextArea textBox;
    protected WordProcessorGUI gui;

	
	public EditMenuHandler (JFrame jf) {
		jframe = jf;
	    textBox = ((WordProcessorGUI) jframe).editingBox;
	    gui = (WordProcessorGUI) jframe;

	}
	
	
	/** Method to determine which File event was selected */
	public void actionPerformed(ActionEvent event) {
		String menuName = event.getActionCommand();
		
		
		//if(menuName.equals("Find & Replace")) FREdit();
		
	}
	
	
	
	private void twoKeyPress(int a, int b) {
		
		try {
			Robot cutRobot = new Robot();
			cutRobot.keyPress(a);
			cutRobot.keyPress(b);
			cutRobot.keyRelease(b);
			cutRobot.keyRelease(a);
		}
		catch(AWTException e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	private void FREdit() {	
		
		
		
		String allText;
		
		if(textBox.getSelectionStart() != textBox.getSelectionEnd())
			allText = textBox.getSelectedText();
		else
			allText = textBox.getText();
	
		
		
		
		
		
		
		
	}
	
	
	
}


