package pck;

import javax.swing.JOptionPane;

public class IllegalFileExtentionException extends IllegalArgumentException {

	/* Thrown when a file does not end in .txt */
	public IllegalFileExtentionException() {
		JOptionPane.showMessageDialog(null, "Error: File has the wrong extention type!");

		
	}
}
