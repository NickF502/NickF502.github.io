package pck;

public class WordProcessorMain {

	public static void main(String[] args) {
		
		WordProcessorGUI myGUI = new WordProcessorGUI("Word Processor by NickF502", 640, 360);
		myGUI.instantiate();
	}

}
