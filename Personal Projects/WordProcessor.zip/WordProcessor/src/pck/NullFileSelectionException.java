package pck;

import javax.swing.JOptionPane;

public class NullFileSelectionException extends IllegalArgumentException {

	/* Thrown when a file does not end in .txt */
	public NullFileSelectionException() {
		JOptionPane.showMessageDialog(null, "File not selected!");

		
	}
}
