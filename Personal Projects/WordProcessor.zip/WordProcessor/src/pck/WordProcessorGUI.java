package pck;

import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class WordProcessorGUI extends JFrame {
	
	
	protected String title;
	protected int height, width;
	
	protected JMenuBar myMenuBar = new JMenuBar();
	protected Container myContentPane = this.getContentPane();
	protected TextArea editingBox = new TextArea();
	

	
	/* Full Constructor */
	public WordProcessorGUI(String t, int h, int w) {
		if(t.equals(null)) throw new IllegalArgumentException("Null Title");
		if(h <= 0 || w <= 0) throw new IllegalArgumentException("Invalid Dimensions");
		
		title = t;
		height = h;
		width = w;
		
		// FIXME Override the window closing event to allow the processor to be saved prior to closing
		addWindowListener(new WindowAdapter() {
            
			@Override
            public void windowClosing(WindowEvent e) {
                FileMenuHandler.closeFile(); // Call your saveGame() function when the window is closed
            }
			
        });

		
	}
	
	
	
	
	/*	A method to create the JFrame and make it visible */
	public void instantiate() {
	    setTitle(title);
		setSize(height, width);
		setLocation(100, 100);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
		/*	Add an override to save the file when closed	*/
		addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                FileMenuHandler.saveFile(true); // Call your saveGame() function when the window is closed
            }
        });	// addWindowListener
		
		createFileMenu();
		createEditMenu();
		
		myContentPane.add(editingBox);
		editingBox.append("Hello! Welcome to my Word Processor! \nYou can type directly in this box, or open a file. \nPlease enjoy!");
		
		
		
		
		
		
		setVisible(true);
	}
	
	
	private void createFileMenu() {
		JMenu fileMenu = new JMenu("File");
		JMenuItem item;
		FileMenuHandler fmh  = new FileMenuHandler(this);
		
		item = new JMenuItem("Open");
		item.addActionListener(fmh);
		fileMenu.add(item);
		
		fileMenu.addSeparator();
		
		item = new JMenuItem("Save");
		item.addActionListener(fmh);
		fileMenu.add(item);

		
		fileMenu.addSeparator();
		
		item = new JMenuItem("Close");
	    item.addActionListener(fmh);
	    fileMenu.add(item);
	    
	    fileMenu.addSeparator();
		
		item = new JMenuItem("Force Close");
	    item.addActionListener(fmh);
	    fileMenu.add(item);

	    setJMenuBar(myMenuBar);
	    myMenuBar.add(fileMenu);

	}
	
	
	
	private void createEditMenu() {
		JMenu editMenu = new JMenu("Edit");
		JMenuItem item;
		EditMenuHandler emh  = new EditMenuHandler(this);
		
		
		
	    item = new JMenuItem("Coming Soon");
		item.addActionListener(emh);
		editMenu.add(item); 
		
		

	    setJMenuBar(myMenuBar);
	    myMenuBar.add(editMenu);

	}
	
	
	
}
